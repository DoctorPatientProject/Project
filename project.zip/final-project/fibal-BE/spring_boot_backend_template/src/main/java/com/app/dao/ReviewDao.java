package com.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.entities.Doctor;
import com.app.entities.Review;

public interface ReviewDao extends JpaRepository<Review, Long> {

	List<Review> findByRdoctorId(Doctor doctor);
	
	// Double getAvgDoctorRatingById(Long doctorId);
	
	@Query("SELECT AVG(r.rating) FROM Review r WHERE r.rdoctorId.doctorId = :doctorId")
    Double getAvgDoctorRatingById(Long doctorId);
}
