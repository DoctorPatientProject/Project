package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.DoctorDao;
import com.app.dao.ReviewDao;
import com.app.dao.UserDao;
import com.app.dto.DisplayReview;
import com.app.dto.ResponseText;
import com.app.dto.ReviewDTO;
import com.app.entities.Doctor;
import com.app.entities.Review;
import com.app.entities.User;

@Service
@Transactional
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	private ReviewDao reviewDao;
	
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private UserDao userDao; //we have used this bcz we have to find user as a patient and set it into appointment
	
	//similarly to doctor which is user
	@Autowired
	private DoctorDao docDao;
	

	
	

	
	
	@Override
	public ResponseText addNewReview(ReviewDTO reviewDto) {
		
		System.out.println("in addNewReview method of" + getClass());
		System.out.println(reviewDto);
		
		Doctor userDoctor = docDao.findById(reviewDto.getDoctorId())
	            .orElseThrow(() -> new ResourceNotFoundException("Invalid Doctor ID!"));
		
	    User userPatient = userDao.findById(reviewDto.getUserId())
	            .orElseThrow(() -> new ResourceNotFoundException("Invalid User ID for Patient!"));

	    

	    Review newReview = new Review();
	    newReview.setRuserId(userPatient);
	    newReview.setRdoctorId(userDoctor);
	    newReview.setRating(reviewDto.getRating());
	    newReview.setReview(reviewDto.getReview());
	    	
	    reviewDao.save(newReview);
	    return new ResponseText("Review added successfully");
	}
	
	
	
//	@Override
//	public List<Review> getReviewById(Long id) {
//		
//		
//		
//		Doctor userDoctor = docDao.findById(id)
//				.orElseThrow(() -> new ResourceNotFoundException("Invalid Dept ID !!!!!"));
//		
//		
//		 return dao.findByRdoctorId(userDoctor);
//	}
	
	
	
	@Override
    public List<DisplayReview> getReviewById(Long doctorId) {
        Doctor doctor = docDao.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid Doctor ID !!!!!"));
        
        List<DisplayReview> rList = new ArrayList<>();
        
        List<Review> reviewList = reviewDao.findByRdoctorId(doctor);
        
        DisplayReview tempReview = new DisplayReview();
        for(Review r : reviewList) {
        	tempReview = mapper.map(r, DisplayReview.class);
        	User userPatient = userDao.findById(r.getRuserId().getUserId())   //here RuserId is user object
    	            .orElseThrow(() -> new ResourceNotFoundException("Invalid User ID for Patient!"));
        	tempReview.setFirstName(userPatient.getFirstName());
        	tempReview.setLastName(userPatient.getLastName());
        	
        	rList.add(tempReview);
        }
        
        return rList;
    }

	@Override
    public Double getAvgDoctorRatingById(Long doctorId) {
        return reviewDao.getAvgDoctorRatingById(doctorId);
    }
	

//	@Override
//	public Double getAvgProductRatingById(Long id) {
//		Product product = productService.getProductById(id).orElseThrow();
//		
//		return dao.getAvgRatingOfProductById(product.getId());
//	}

//	@Override
//	public List<AvgRatingResponseDTO> getAvgProductRatingOfAllProducts() {
//		return dao.getAvgRatingProductOfAllProducts();
//	}
	
}
