package com.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.dto.SignUpDetails;
import com.app.entities.Doctor;
import com.app.entities.User;

public interface UserDao extends JpaRepository<User, Long> {
	Optional<User> findByEmailAndPassword(String em,String pass);
	
			List<User> findByDr(Doctor dr);
			
			User findByEmail(String emailId);
			
			//SignUpDetails findByEmail(String emailId);
			
			 SignUpDetails save(SignUpDetails signUpDetails);		
			
}
