package com.app.entities;

public enum RoleType {
	USER,DOCTOR
}
