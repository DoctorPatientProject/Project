package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ReviewDTO;
import com.app.service.ReviewService;

@RestController
@RequestMapping("/review")
@CrossOrigin(origins = "http://localhost:3000")
public class ReviewController {

	@Autowired
	private ReviewService reviewService;
	
	@PostMapping
	public ResponseEntity<?> addNewReview(@RequestBody ReviewDTO review)
	{
		System.out.println("in addNewReview method of" + getClass());
		System.out.println(review);
		return ResponseEntity.status(HttpStatus.CREATED).body(reviewService.addNewReview(review));
	}
	
	
	@GetMapping("/{doctorId}")
	public ResponseEntity<?> getReviewByDoctorId(@PathVariable Long doctorId)
	{
		return ResponseEntity.status(HttpStatus.OK).body(reviewService.getReviewById(doctorId));
	}
	
	
	
	
	//Avgerage rating by each individual doctor by id
	@GetMapping("/rating{doctorId}")
	public ResponseEntity<?> getAvgProductRatingById(@PathVariable Long doctorId)
	{
		return ResponseEntity.status(HttpStatus.OK).body(reviewService.getAvgDoctorRatingById(doctorId));
	}
	
	//Avgerage rating by all product
//	@GetMapping("/avg")
//	public ResponseEntity<?> getAvgProductRatingOfAll()
//	{
//		return ResponseEntity.status(HttpStatus.OK).body(reviewService.getAvgProductRatingOfAllProducts());
//	}
	
	
	
}
