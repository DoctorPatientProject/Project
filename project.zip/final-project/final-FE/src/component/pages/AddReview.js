// import React, { useState } from 'react';
// import axios from 'axios';
// import { Container, Form, Button } from 'react-bootstrap';
// import { FaStar } from 'react-icons/fa';

// const StarRating = ({ rating, onRatingChange }) => {
//   const renderStars = () => {
//     const stars = [];
//     for (let i = 1; i <= 5; i++) {
//       stars.push(
//         <FaStar
//           key={i}
//           onClick={() => onRatingChange(i)}
//           color={i <= rating ? 'gold' : 'lightgrey'}
//         />
//       );
//     }
//     return stars;
//   };

//   return <div>{renderStars()}</div>;
// };

// const AddReview = () => {
//   const [rating, setRating] = useState(0);
//   const [comment, setComment] = useState('');

//   const handleAddReview = () => {
//     const newReview = {
//       rating,
//       comment,
//     };

//     axios.post('http://localhost:8080/review', newReview)
//       .then((response) => {
//         // Handle success
//         alert('Review added successfully');
//         setRating(0);
//         setComment('');
//       })
//       .catch((error) => {
//         // Handle error
//         console.error('Error adding review:', error);
//         alert('Failed to add review');
//       });
//   };

//   return (
//     <Container>
//       <h2>Add New Review</h2>
//       <Form>
//         <Form.Group>
//           <Form.Label>Rating</Form.Label>
//           <StarRating rating={rating} onRatingChange={setRating} />
//         </Form.Group>
//         <Form.Group>
//           <Form.Label>Comment</Form.Label>
//           <Form.Control
//             as="textarea"
//             rows={3}
//             value={comment}
//             onChange={(e) => setComment(e.target.value)}
//           />
//         </Form.Group>
//         <Button variant="primary" onClick={handleAddReview}>
//           Add Review
//         </Button>
//       </Form>
//     </Container>
//   );
// };

// export default AddReview;

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Container, Form, Button } from 'react-bootstrap';
import { FaStar } from 'react-icons/fa';

const StarRating = ({ rating, onRatingChange }) => {
  const renderStars = () => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <FaStar
          key={i}
          onClick={() => onRatingChange(i)}
          color={i <= rating ? 'gold' : 'lightgrey'}
        />
      );
    }
    return stars;
  };

  return <div>{renderStars()}</div>;
};

const AddReview = () => {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [userId, setUserId] = useState('');
  const [doctorId, setDoctorId] = useState('');
  const [doctors, setDoctors] = useState([]);
  

  useEffect(() => {
    // Retrieve userId from sessionStorage
    const storedUserId = sessionStorage.getItem('user_id');
    if (storedUserId) {
      setUserId(storedUserId);
    }

    // Fetch doctors and populate the dropdown
    fetchDoctors();
  }, []);

  const fetchDoctors = async () => {
    try {
      const response = await axios.get('http://localhost:8080/doctors');
      setDoctors(response.data);
    } catch (error) {
      console.error('Error fetching doctors:', error);
    }
  };

  const handleAddReview = () => {
    const newReview = {
      rating,
      comment,
      doctorId,
      userId,
    };

    axios.post('http://localhost:8080/review', newReview)
      .then((response) => {
        // Handle success
        alert('Review added successfully');
        setRating(0);
        setComment('');
      })
      .catch((error) => {
        // Handle error
        console.error('Error adding review:', error);
        alert('Failed to add review');
      });
  };

  return (
    <Container>
      <h2>Add New Review</h2>
      <Form>
        <Form.Group>
          <Form.Label>Select Doctor</Form.Label>
          <Form.Control as="select" onChange={(e) => setDoctorId(e.target.value)}>
            <option value="">Select a doctor</option>
            {doctors.map((doctor) => (
              <option key={doctor.doctorId} value={doctor.doctorId}>
                {doctor.name} {/* Replace with the actual doctor's name */}
              </option>
            ))}
          </Form.Control>
        </Form.Group>
        <Form.Group>
          <Form.Label>Rating</Form.Label>
          <StarRating rating={rating} onRatingChange={setRating} />
        </Form.Group>
        <Form.Group>
          <Form.Label>Comment</Form.Label>
          <Form.Control
            as="textarea"
            rows={3}
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
        </Form.Group>
        
        {/* Hidden input for userId */}
        <input type="hidden" name="userId" value={userId} />
        
        <Button variant="primary" onClick={handleAddReview}>
          Add Review
        </Button>
      </Form>
    </Container>
  );
};

export default AddReview;
