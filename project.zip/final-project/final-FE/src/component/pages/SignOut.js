import React, { useEffect } from 'react';
import { useHistory } from 'react-router-dom';

function SignOut() {
  const history = useHistory();

  useEffect(() => {
    // Clear session storage
    window.sessionStorage.clear();

    // Redirect to the SignIn page after logging out
    history.push('/SignIn');
    window.location.reload() ;
  }, [history]);

  return (
    <div>
      {/* You can optionally display a message or loading indicator here */}
      Logging out...
    </div>
  );
}

export default SignOut;
