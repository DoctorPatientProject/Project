// import React from 'react'
// import '../../App.css'

// function Contacts() {
//   return (
//     <div className='contacts'>Contacts</div>
//   )
// }

// export default Contacts

import React from 'react'
import '../../App.css'

function Contacts() {
  return (
    
    <div className="contacts">
    
      <div className="contact-details">
        <p><strong>Email:</strong> emed23@gmail.com</p>
        <p><strong>Phone:</strong> +91 7012584990</p>
        <p><strong>Address:</strong> Sunbeam Infotech, Karad</p>
      </div>
     
    </div>
    
  )
};

export default Contacts