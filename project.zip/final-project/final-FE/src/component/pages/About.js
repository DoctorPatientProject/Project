// import React from 'react';
// import '../../App.css'

// function About() {
//   return (
//     <div className='about'>About</div>
//   )
// }

// export default About

// import React from 'react';
// import '../../App.css'

// function About() {
//   return (
//     <div className='about'>
//       <div className='title'>
//         <center><i><h1>Our Mission</h1></i></center>
//       </div>
//       <div className='paragraph'>
//         <p>
//           <h4>
//           <br/><br/><br/>
//             E-Med is on a mission to make quality healthcare affordable and accessible for over a billion+ Indians.<br />
//             We believe in empowering our users with the most accurate, comprehensive, and curated information and care,<br />
//             enabling them to make better healthcare decisions.
//           </h4>
//         </p>
//       </div>
     
    
//       {/* <div className='title'>
//         <i><h1>Health is a habit</h1></i>
//       <div/>
//       <div className='paragraph'>
//         <p>
//           <h5>
//           <br/><br/>
//           It is the journey that takes you to new destinations<br/>
//           every day with endless possibilities of life on the <br/>
//           back of happiness, energy, and hope. Practo wants to<br/>
//           make this journey easy for every Indian and help them<br/>
//           live healthier and longer lives.
//       </h5>
//         </p>
//       </div>
//       </div> */}
//        <div className="about-page">
//       <h1>Quality Heathcare Made Simple</h1> 
      
//       {/* <center>
//       <p className='special-line'>
//         Each time a patient finds the right doctor, we build a healthier nation
//       </p>
//     </center>*/}
//       <div id="bottom">
//       <p className='special-line'>
//       Each time a patient finds the right doctor, we build a healthier nation
//       </p>
//       </div>
//     </div>
//     </div>
    
//   );
// };

// export default About;

import React from 'react';
import '../../App.css';

function About() {
  return (
    <div className='about'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-4 mx-auto'>
            <div className='card' style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)' }}>
              <div className='card-body text-center'>
                <h1 className='card-title'>Our Mission</h1>
                <p className='card-text fs-5'>
                  E-Med is on a mission to make quality healthcare affordable and accessible for over a billion+ Indians.
                  We believe in empowering our users with the most accurate, comprehensive, and curated information and care,
                  enabling them to make better healthcare decisions.
                </p>
                <p className='card-text fs-5'>
                  Each time a patient finds the right doctor, we build a healthier nation.
                </p>
              </div>
            </div>
          </div>
          <div className='col-md-4'>
        <div className='cards' style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)' }}>
    <img src="/images/About.jpeg" className="card-img-top" alt="Image Alt Text" />
  </div>
</div>

        </div>
      </div>
    </div>
  );
}

export default About;

