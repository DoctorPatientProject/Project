import React from 'react';
import { Link, Route, Switch } from 'react-router-dom';
import Navbar from './Navbar'; // Import your Navbar component
import Footer from './Footer'; // Import your Footer component
import MyProfile from './MyProfile'; // Import your profile component
import ViewDepartment from './ViewDepartment'; // Import other components
import ViewAppointment from './ViewAppointment';
import Prescription from './Prescription';
import Review from './Review';

function Layout() {
  return (
    <div className="layout">
      <div className="sidebar">
        <Link to="/profile">My Profile</Link>
        <Link to="/department">View Department</Link>
        <Link to="/appointment">View Appointment</Link>
        <Link to="/prescription">Prescription</Link>
        <Link to="/review">Review</Link>
        {/* You can add more links here */}
      </div>
      <div className="content">
        <Navbar />
        <Switch>
          <Route path="/profile" component={MyProfile} />
          <Route path="/department" component={ViewDepartment} />
          <Route path="/appointment" component={ViewAppointment} />
          <Route path="/prescription" component={Prescription} />
          <Route path="/review" component={Review} />
          {/* Define routes for other components */}
        </Switch>
        <Footer />
      </div>
    </div>
  );
}

export default Layout;
