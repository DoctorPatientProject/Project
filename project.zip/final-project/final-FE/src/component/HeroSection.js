import React from 'react';
import './HeroSection.css';
import '../App.css';
// import { Button } from './Button';



function HeroSection() {
  return (
    
    <div className='hero-container'>
      <h1>THE BEST DOCTOR GIVES</h1>
      <h1>THE LEAST MEDICINE</h1>
    </div>
  )
}

export default HeroSection