import httpClient from '../component/http-common';

const createOTP=(Email)=>{
    return httpClient.post('users/getotpforforgotpass',Email);
  }

  const verifyOTP=(otp)=>{
        return httpClient.post('users/verify-otpforforgot',otp); 

  }

  const adddchangedpass=(saveforgorObject)=>{
    
    return httpClient.post('users/storenewpass',saveforgorObject); 


  }

  // const changepassword=(user)=>{

  //   return httpClient.post('users/change',user)
  // }

  export default { createOTP, verifyOTP, adddchangedpass };