// import React from 'react';
// //import '../../App.css';
// //import 'bootstrap/dist/css/bootstrap.min.css';
// //import './login.css'
// import { Link } from "react-router-dom";

// import { useState } from "react";
// import { toast } from "react-toastify";
// import config from "../../config";
// import axios from "axios";

// //function SignIn() {

// const SignIn = () => {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");

//   const signinUser = () => {
//     // ... your existing signinUser logic ...
//   };

// return (
//   <div className='sign-in'>
//   <div className="container mt-5">
//     <div className="row justify-content-center">
//       <div className="col-md-6 col-lg-4">
//         <div className="card">
//           <div className="card-body">
//             <h2 className="card-title text-center mb-4">Sign In</h2>
//             <form>
//               <div className="mb-3">
//                 <input
//                   type="email"
//                   className="form-control"
//                   placeholder="Email address"
//                   onChange={(event) => setEmail(event.target.value)}
//                 />
//               </div>
//               <div className="mb-3">
//                 <input
//                   type="password"
//                   className="form-control"
//                   placeholder="Password"
//                   onChange={(event) => setPassword(event.target.value)}
//                 />
//               </div>
//               <div className="text-center">
//               <button
//                 className="btn btn-primary btn-lg"
//                 onClick={signinUser} 
              
//               >
//                 Sign In
//               </button>
//               </div>
//             </form>
//             <div className="mt-3 text-center">
//               Don't have an account? <Link to="/signup">Sign Up</Link>
//             </div>
//             <div className="mt-2 text-center">
//               <Link to="/forget">Forgot Password?</Link>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   </div>
//   </div>
// );
// };

// export default SignIn;

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button, Card, Form } from 'react-bootstrap';
import axios from 'axios';
import { toast } from "react-toastify";
import { useHistory } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const SignIn = () => {
  const history = useHistory();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const requestData = {
      email,
      password,
    };

    axios
      .post('http://localhost:8080/users/signin', requestData) // Replace with your backend API URL
      .then((response) => {
        // Handle successful login
        const { userId, role, firstName } = response.data;

        // Store user information in local storage
        sessionStorage.setItem('userId', userId);
        sessionStorage.setItem('role', role);
        sessionStorage.setItem('firstName', firstName);
        sessionStorage.setItem('isUserLoggedIn', "true");
        toast.success('Login successful!',{ autoClose: 2000 }); // If you're using a notification library like 'react-toastify'
      
        setTimeout(() => {
        if (role === 'USER') {
          sessionStorage.setItem('user_id', userId);
        const user_id = sessionStorage.getItem('user_id');
        // localStorage.setItem('user_id', userId);
        // const user_id = localStorage.getItem('user_id');
        history.push('/DepartmentList');
        window.location.reload() ;
      } else if (role === 'DOCTOR') {
        sessionStorage.setItem('user_id', userId);
        const user_id = sessionStorage.getItem('user_id');
        history.push(`/appointmemts/${user_id}`);
        window.location.reload() ;
      } else {
        // Handle other roles here if needed
        console.log('Unknown role:', role);
      }
    },2000);

        //console.log('Login Successful:', response.data);
      })
      .catch((error) => {
        // Handle login error
        history.push('/SignIn')
        toast.error('Login failed. Please check your credentials.',{ autoClose: 2000 }); // If you're using a notification library like 'react-toastify'

        //console.error('Login Error:', error);
      });
  };

  return (
    <div className='sign-in'>
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6 col-lg-4">
          <Card>
            <Card.Body>
              <Card.Title className="text-center mb-4">Sign In</Card.Title>
              <Form onSubmit={handleSubmit}>
                <Form.Group controlId="email">
                  {/* <Form.Label>Email</Form.Label> */}
                  <Form.Control
                    type="email"
                    placeholder="Enter email"
                    value={email}
                    onChange={handleEmailChange}
                  />
                  <br></br>
                </Form.Group>
                <Form.Group controlId="password">
                  {/* <Form.Label>Password</Form.Label> */}
                  <Form.Control
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={handlePasswordChange}
                  />
                  <br></br>
                </Form.Group>
                <div className="text-center">
                  <Button variant="primary" type="submit">
                    Sign In
                  </Button>
                </div>
              </Form>
              <div className="mt-3 text-center">
                Don't have an account? <Link to="/signup">Sign Up</Link>
              </div>
              <div className="mt-2 text-center">
                <Link to="/ForgotPassword">Forgot Password?</Link>
              </div>
            </Card.Body>
          </Card>
        </div>
      </div>
    </div>
    <ToastContainer />
    </div>
  );
};

export default SignIn;
