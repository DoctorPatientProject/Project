// // import React from 'react';
// // import './DepartmentList.css'; // Import your CSS file for styling

// // const DepartmentList = () => {
// //   const departments = [
// //     { name: 'Cardiology', imageSrc: '/images/cardiology.jpeg' },
// //     { name: 'Orthopedics', imageSrc: '/images/orthopedic.jpeg' },
// //     { name: 'Pediatrics', imageSrc: '/images/pediatrics1.jpg' },
// //     // Add more departments
// //   ];

// //   return (
// //     <div className="department-list">
// //       {departments.map((department, index) => (
// //         <div className="department-circle" key={index}>
// //           <img src={department.imageSrc} alt={department.name} />
// //           <p>{department.name}</p>
// //         </div>
// //       ))}
// //     </div>
// //   );
// // };

// // export default DepartmentList;
// import React from 'react';
// import { Card } from 'react-bootstrap'; // Import Bootstrap components
// //import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS

// const DepartmentList = () => {
//   const departments = [
//     { name: 'Cardiology', imageSrc: '/images/cardiology.jpeg' },
//     { name: 'Orthopedics', imageSrc: '/images/orthopedic.jpeg' },
//     { name: 'Pediatrics', imageSrc: '/images/pediatrics1.jpg' },
//     // Add more departments
//   ];

//   return (
//     <div className="department-list container">
//       <div className="row justify-content-center">
//         {departments.map((department, index) => (
//           <div className="col-md-4 col-lg-3 mb-4" key={index}>
//             <Card className="department-circle text-center d-flex align-items-center justify-content-center">
//               <Card.Img variant="top" src={department.imageSrc} className="img-fluid rounded-circle" style={{ width: '100px', height: '100px' }} />
//               <Card.Body>
//                 <Card.Title>{department.name}</Card.Title>
//               </Card.Body>
//             </Card>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default DepartmentList;


import React from 'react';
//import { useHistory } from 'react-router-dom'; // Import useHistory from react-router-dom
import './mycss.css'; // Make sure to adjust the CSS path
//import { Navigate } from "react-router-dom";
import { useHistory } from 'react-router-dom';

const DepartmentList = () => {
  const departments = [
    { name: 'General', imageSrc: '/images/General.jpeg', id: 1 },
    { name: 'Cardiology', imageSrc: '/images/cardiology.jpeg', id: 2 },
    { name: 'Orthopedics', imageSrc: '/images/orthopedic.jpeg', id: 3 },
    { name: 'ENT', imageSrc: '/images/ENT.jpeg', id: 4 },
    { name: 'DENTISTRY', imageSrc: '/images/Dentistry.jpeg', id: 5 },
    { name: 'DERMATOLOGY', imageSrc: '/images/Dermatolgy.jpeg', id: 6 },
    // Add more departments
  ];
  //const history = useNavigate(); 
  const history = useHistory(); // Get the history object

  const handleDivClick = (departmentId) => {
    // Redirect to a new route with the departmentId as a query parameter
    //navigate(`/doctors/${departmentId}`);
    history.push(`/doctors/${departmentId}`);
  };

  return (
    <div className="department-list container">
    <div className="row">
      {departments.map((department) => (
        <div
          className="col-md-4 col-sm-6 department-card" // Adjust the column classes for responsiveness
          key={department.id}
          onClick={() => handleDivClick(department.id)}
        >
          <div className="text-center department" >
            <img src={department.imageSrc} alt={department.name} className="department-image" />
            <p>{department.name}</p>
          </div>
        </div>
      ))}
    </div>
  </div>

    // <div className="department-list container">
    //   <div className="row justify-content-center">
    //     {departments.map((department) => (
    //       <div
    //         className="col-md-4 department-card"
    //         key={department.id}
    //         onClick={() => handleDivClick(department.id)}
    //       >
    //         <div className="text-center">
    //           <img src={department.imageSrc} alt={department.name} />
    //           <p>{department.name}</p>
    //         </div>
    //       </div>
    //     ))}
    //   </div>
    // </div>
  );
};

export default DepartmentList;
