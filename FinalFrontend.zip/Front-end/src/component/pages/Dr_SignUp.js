// import React, { useState } from 'react';
// //import { Link } from 'react-router-dom';
// import { useHistory } from 'react-router-dom';

// function DoctorSignUp() {
//   const [qualification, setQualification] = useState('');
//   const [speciality, setSpeciality] = useState('');
//   const history = useHistory(); // Use React Router's useHistory hook

//   const handleQualificationChange = (event) => {
//     setQualification(event.target.value);
//   };

//   const handleSpecialityChange = (event) => {
//     setSpeciality(event.target.value);
//   };

//   const handleSignUp = (event) => {
//     event.preventDefault();
//     // Add your signup logic here

//     // Redirect to signin page after signup
//     history.push('/signin');
//   };


//   return (
//     <div className='sign-up'>
//       <div className="container mt-5">
//          <div className="row justify-content-center">
//         <div className="col-md-8 col-lg-6">
//           <div className="card">
//             <div className="card-body">
//               <h2 className="card-title text-center mb-4">Doctors Sign Up</h2>
//               {/* <form> */}
//               <form onSubmit={handleSignUp}>
//                 <div className="mb-3">
//                   <label htmlFor="qualification" className="form-label">
//                     Qualification
//                   </label>
//                   <input
//                     type="text"
//                     className="form-control"
//                     id="qualification"
//                     value={qualification}
//                     onChange={handleQualificationChange}
//                     required
//                   />
//                 </div>
//                 <div className="mb-3">
//                   <label htmlFor="speciality" className="form-label">
//                     Speciality
//                   </label>
//                   <input
//                     type="text"
//                     className="form-control"
//                     id="speciality"
//                     value={speciality}
//                     onChange={handleSpecialityChange}
//                     required
//                   />
//                 </div>
//                 <div className="text-center">
//                   <button className="btn btn-primary btn-lg" type="submit">
//                     Sign Up
//                   </button>
//                 </div>
//               </form>
//               {/* <div className="mt-3 text-center">
//                 Already have an account? <Link to="/signin">Sign In</Link>
//               </div> */}
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//  </div>
//   );
// }

// export default DoctorSignUp;

import React, { useState } from "react";
import "./Add_User.css";
import user from "/home/sunbeam/Desktop/app2/app2/src/img/useravatar.png";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useHistory } from "react-router-dom"; // Import useHistory from react-router-dom
import axios from "axios"; // Import axios

const notify = (text) => toast(text);

const Add_Doctor = () => {
  const [loading, setLoading] = useState(false);
  var uid = sessionStorage.getItem('userId');
  const [UserValue, setUserValue] = useState({
    userId:uid,
    email: "",
    qualification: "",
    about: "",
    address: "",
    fees: 0,
    dept_id: 1,
  });

  const history = useHistory(); // Get the history object

  const HandleDoctorChange = (e) => {
    setUserValue({ ...UserValue, [e.target.name]: e.target.value });
  };

  const HandleDoctorSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    debugger

    // Make a POST request using axios
    axios
      .post("http://localhost:8080/doctors/add", UserValue)
      .then((response) => {
        if (response.data.message === "User already exists") {
          setLoading(false);
          return notify("User Already Exists");
        }
        const userId = response.data.userId;
        notify("Doctor specific info Added");
        window.sessionStorage.clear();
        history.push("/SignIn"); // Use history.push for navigation
      })
      .catch((error) => {
        setLoading(false);
        notify("Something went wrong, Please try again");
      });
  };

  return (
    <>
      <ToastContainer />
      <div className="container">
        <div className="AfterSideBar">
          <div className="Main_Add_Doctor_div">
            <h1>Add User</h1>
            <img src={user} alt="doctor" className="avatarimg" />
            <form onSubmit={HandleDoctorSubmit}>
              <div>
                <label>Email</label>
                <div className="inputdiv">
                  <input
                    type="email"
                    placeholder="abc@abc.com"
                    name="email"
                    value={UserValue.email}
                    onChange={HandleDoctorChange}
                    required
                  />
                </div>
              </div>
              <div>
                <label>Enter Your Qualification</label>
                <div className="inputdiv">
                  <input
                    type="text"
                    placeholder="e.g. MBBS"
                    name="qualification"
                    value={UserValue.qualification}
                    onChange={HandleDoctorChange}
                    required
                  />
                </div>
              </div>
              <div>
                <label>Select Speciality</label>
                <div className="inputdiv">
                  <select
                    name="dept_id"
                    value={UserValue.dept_id}
                    onChange={HandleDoctorChange}
                    required
                  >
                    <option value="Choose role">Select</option>
                    <option value="1">GENERAL_MEDICINE</option>
                    <option value="2">CARDIOLOGY</option>
                    <option value="3">ORTHOPEDIC</option>
                    <option value="4">ENT</option>
                    <option value="5">DENTISTRY</option>
                    <option value="6">DERMATOLOGY</option>
                  </select>
                </div>
              </div>
              <div>
                <label>Address</label>
                <div className="inputdiv">
                  <input
                    type="text"
                    placeholder="e.g. Pune"
                    name="address"
                    value={UserValue.address}
                    onChange={HandleDoctorChange}
                    required
                  />
                </div>
              </div>
              <div>
                <label>Fees</label>
                <div className="inputdiv">
                  <input
                    type="number"
                    placeholder="E.g. 100"
                    name="fees"
                    value={UserValue.fees}
                    onChange={HandleDoctorChange}
                    required
                  />
                </div>
              </div>
              <div>
                <label>Other Info About Me</label>
                <div className="inputdiv">
                  <textarea
                    placeholder="Extra Info"
                    rows="4"
                    cols="50"
                    name="about"
                    value={UserValue.about}
                    onChange={HandleDoctorChange}
                    required
                  />
                </div>
              </div>
              <button type="submit" className="formsubmitbutton">
                {loading ? "Loading..." : "Submit"}
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Add_Doctor;
