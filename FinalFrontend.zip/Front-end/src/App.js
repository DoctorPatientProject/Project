
import { Component } from "react";
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';

// import { Switch,Route } from 'react-router-dom';

import './App.css'
import Navbar from "./component/Navbar";
import Home from "./component/pages/Home";
import About from "./component/pages/About";
import Contact from "./component/pages/Contacts";
import SignIn from "./component/pages/SignIn";
import SignUp from "./component/pages/SignUp";
//import { Footer } from "antd/es/layout/layout";
import Footer from "./component/Footer";
import DoctorSignUp from "./component/pages/Dr_SignUp";
import DepartmentList from './component/pages/DepartmentList'
import UpdateProfile from './component/pages/UpdateProfile'
import DoctorAppointments from './component/pages/DoctorAppointments'
import PatientAppointments from './component/pages/PatientAppointments'
import ViewProfile from './component/pages/ViewProfile'
import Prescription from './component/pages/Prescription'
import GetPrescription from './component/pages/GetPrescription'
import AddReview from './component/pages/AddReview'
import ProtectedRoute from "./component/ProtectedRoute";
import SignOut from "./component/pages/SignOut"
import ForgotPassword from './component/ForgotPassword'
import Doctors from './component/pages/Doctors'
import BookAppointment from './component/pages/BookAppointment'

class App extends Component
{
    render()
    {
        return (
        <>
        <Router>
             <Navbar />
             <div className="content">
                <Switch>
                    <Route path='/' exact component = {Home} />
                    <Route path='/About' exact component = {About} />
                    <Route path='/Contacts' exact component = {Contact} />
                    <Route path='/SignIn' exact component = {SignIn} />
                    <Route path='/SignUp' exact component = {SignUp} />
                    <Route path='/Dr_SignUp' exact component = {DoctorSignUp} />
                    {/* <Route path='/DepartmentList' exact component = {DepartmentList} /> */}
                    <ProtectedRoute exact path="/DepartmentList" component={DepartmentList}></ProtectedRoute>
                    <ProtectedRoute path='/UpdateProfile/:user_id' exact component = {UpdateProfile} />
                    <ProtectedRoute path="/appointmemts/:user_id" exact component={DoctorAppointments} />
                    <ProtectedRoute path="/appointmemts/p/:user_id" exact component={PatientAppointments} />
                    <ProtectedRoute path="/ViewProfile/:user_id" exact component={ViewProfile}/>
                    <ProtectedRoute path="/Prescription" exact component={Prescription}/>
                    <ProtectedRoute path="/GetPrescription" exact component={GetPrescription} />
                    <ProtectedRoute path="/AddReview" exact component={AddReview}/>
                    <ProtectedRoute path="/SignOut" exact component={SignOut}/>
                    <ProtectedRoute path="/Doctors/:deptId" exact component={Doctors}/>
                    <Route path='/ForgotPassword' exact component = {ForgotPassword} />
                    <ProtectedRoute path="/BookAppointment" exact component={BookAppointment}/>
                    
                </Switch>
                </div>
                <Footer/>
        </Router>
        </>);
    }
}

export default App;
